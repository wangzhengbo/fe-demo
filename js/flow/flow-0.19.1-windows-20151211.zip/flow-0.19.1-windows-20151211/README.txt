Flow compiled on Dec 04, 2015, commit 97f864abeb1a9866d4daf8662e9a6185046880e4

To test Flow, we provide a test.js:

 $> ./flow.exe init
 $> ./flow.exe check

Flow was compiled using ocpwin (http://www.typerex.org/ocpwin.html).

BUGS
====
Fow now, for any issue, use:

http://www.github.com/OCamlPro/flow or
http://www.github.com/facebook/flow

-----------------
The OCamlPro team.
